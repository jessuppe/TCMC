To update patch.exe open a vs command prompt and run in .\bin
mt -manifest patch.exe.manifest -outputresource:patch.exe;1

see http://math.nist.gov/oommf/software-patchsets/patch_on_Windows7.html for further instructions of necessary