# platform
Platform support library used by libCEC and binary add-ons for Kodi

