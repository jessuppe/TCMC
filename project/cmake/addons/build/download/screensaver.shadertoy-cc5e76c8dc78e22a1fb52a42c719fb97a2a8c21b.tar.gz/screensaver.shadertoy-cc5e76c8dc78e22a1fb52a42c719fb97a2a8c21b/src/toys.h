// include file for screensaver template
