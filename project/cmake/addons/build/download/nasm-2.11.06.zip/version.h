#ifndef NASM_VERSION_H
#define NASM_VERSION_H
#define NASM_MAJOR_VER      2
#define NASM_MINOR_VER      11
#define NASM_SUBMINOR_VER   6
#define NASM_PATCHLEVEL_VER 0
#define NASM_VERSION_ID     0x020b0600
#define NASM_VER            "2.11.06"
#endif /* NASM_VERSION_H */
